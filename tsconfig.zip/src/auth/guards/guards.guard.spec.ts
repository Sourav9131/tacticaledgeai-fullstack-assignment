import { GuardsGuard } from './guards.guard';

describe('GuardsGuard', () => {
  it('should be defined', () => {
    expect(new GuardsGuard()).toBeDefined();
  });
});
